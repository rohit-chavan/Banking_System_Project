package com.lti.day1.main;

public interface I1 {
	public void display();
	default public void show() {
		System.out.println("JDK1.8");
	}
}
