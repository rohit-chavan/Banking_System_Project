package com.lti.day1.main;

public class Derived extends AbstractDemo{
	
	
	public void sample() {
		System.out.println("Derived");
		// TODO Auto-generated method stub

	}		

}
