package com.lti.day1.main;

public class I1_Class implements I1 {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		I1_Class i = new I1_Class();
		i.display();
		i.show();
	}

}
