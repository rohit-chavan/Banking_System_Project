package com.lti.day1.service;

import java.util.Scanner;

import com.lti.day1.bean.Employee;

public class Employee_Service {
	private static int count; 
	private Employee employees[] =new Employee[10];
	public String addEmployee(Employee employee) {
		if(employees.length<=count) {
			return "Array full";
		}
		else {
			employees[count] = employee;
			count++;
			return "Success";
		}
		
	}
	
	public Employee getEmployeeById(String id) {
		for (Employee employee : employees) {
			if(id.equals(employee.getEmployeeId())) {
				return employee;
			}
			/*else {
				return null;
			}*/
		}
		//return null;
	return null;
	}
	//int counter=0;
	public String deleteEmployeeById(String id) {
		/*for (Employee employee : employees) {
			if(id.equals(employee.getEmployeeId())) {
				employee.setEmployeeId(null);
				employee.setEmployeeName(null);
				//employees[counter]=null;
				return "deleted";
			}
			else {
				//counter++;
				return null;
			}
		}*/
		for(int i=0;i<employees.length;i++) {
			if(id.equals(employees[i].getEmployeeId())){
				employees[i].setEmployeeId(null);
				employees[i].setEmployeeName(null);
				return "Deleted";
			}
			else {
				return "Not Deleted";
			}
		}
		return null;
		}
	}
	
	
