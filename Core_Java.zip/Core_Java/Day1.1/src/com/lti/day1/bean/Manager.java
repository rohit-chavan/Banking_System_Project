package com.lti.day1.bean;

import com.lti.day1.bean.Employee;

public final class  Manager extends Employee {
	int c;
	float salary;
	
	private float projectAllowance;

	public float getProjectAllowance() {
		return projectAllowance;
	}

	public void setProjectAllowance(float projectAllowance) {
		this.projectAllowance = projectAllowance;
	}

	@Override
	 public float calculateSalary() {
		
		net_sal = super.calculateSalary()+this.projectAllowance;
		//System.out.println("ManagerSAL="+net_sal);
		// TODO Auto-generated method stub
		return net_sal;
	}
	

	/*public Manager(int a,int b) {
		super(1);
		// TODO Auto-generated constructor stub
	}*/
	
	/*public Manager() {
		
	}*/
	/*public Manager() {
		//super();
		//this(a,b);
		//this.salary=salary;
		System.out.println("Manager Constructor");
	}*/
}
