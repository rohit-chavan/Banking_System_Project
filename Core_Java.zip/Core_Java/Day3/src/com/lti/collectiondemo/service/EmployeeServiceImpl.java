package com.lti.collectiondemo.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import java.util.stream.Collectors;


public class EmployeeServiceImpl implements EmployeeService{
	
	private HashSet<Employee> hashSet = new HashSet<>();
	
	
	
	private ArrayList<Employee> employees = new ArrayList<>();
	
	@Override
	public String addEmployee(Employee employee) {
		try {
			//hashSet.add(employee);
			if(hashSet.add(employee)){
				return "true";
			}
			else {
				return "false";
			}
			//System.out.println(getEmployees());
			//return "success";
			
		}
		catch(Exception e){
			return "fail";
		}
		
	}

	@Override
	public Employee getEmployeeById(String id) {
		
		Iterator<Employee> iterator = hashSet.iterator();
		while (iterator.hasNext()) {
			Employee employee = (Employee) iterator.next();
			if (employee.getEmployeeId().equals(id)) {
				return employee;
			}
			
		}
		
		return null;
		/*Optional <Employee> optional = employees.stream().filter(emp1 -> id.equals(emp1.getEmployeeId())).findFirst();
		if(optional.isPresent()) {
			Employee employee = optional.get();
		
		}
		else {
			System.out.println("Not found");
		}*/

		
		//employees.forEach(System.out::println);
		//return employees.stream().filter(emp1 -> id.equals(emp1.getEmployeeId())).collect(Collectors.toList()).get(0);
		//employees.stream().filter(emp1 -> id.equals(emp1.getEmployeeId())).collect(Collectors.toList()).get(0)
		//return optional;
		/*employees.forEach(emp1 -> {
			if(id.equals((emp1.getEmployeeId())))
					{
				System.out.println("record found");
			}
			else {
				System.out.println("record not found");
			}
		});
		return null;*/
		
		/*
		ListIterator<Employee> iterator = employees.listIterator();
		while (iterator.hasNext()) {
			Employee employee = (Employee) iterator.next();
			if(id.equals(employee.getEmployeeId())) {
				return employee;
			}
		}*/
			/*Iterator<Employee> iterator = employees.iterator();
			while(iterator.hasNext()) {
				Employee employee = (Employee) iterator.next();	
				if(id.equals(employee.getEmployeeId())) {
					return employee;
				}
			}
			return null;*/
			
		/*}
		return null;*/
		/*for(Employee employee : employees) {
			if(id.equals(employee.getEmployeeId())) {
				return employee;
			}
		}
		// TODO Auto-generated method stub
		return null;*/
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((employees == null) ? 0 : employees.hashCode());
		result = prime * result + ((hashSet == null) ? 0 : hashSet.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeServiceImpl other = (EmployeeServiceImpl) obj;
		if (employees == null) {
			if (other.employees != null)
				return false;
		} else if (!employees.equals(other.employees))
			return false;
		if (hashSet == null) {
			if (other.hashSet != null)
				return false;
		} else if (!hashSet.equals(other.hashSet))
			return false;
		return true;
	}

	@Override
	public List<Employee> getEmployees() {
		hashSet.forEach(System.out::println);
		return new ArrayList<Employee> (hashSet);
	}

	@Override
	public String deleteEmployee(String id) {
		Optional <Employee> optional = hashSet.stream().filter(emp1 -> id.equals(emp1.getEmployeeId())).findFirst();
		if(optional.isPresent()) {
			//Employee employee = optional.get();
			hashSet.remove(optional.get());
			System.out.println("Deleted");
		}
		else {
			System.out.println("Not Deleted");
		}
		
		return null;
	}

	@Override
	public String updateEmployee(String id, Employee employee) {
		deleteEmployee(id);
		addEmployee(employee);
		return null;
	}

	
}
