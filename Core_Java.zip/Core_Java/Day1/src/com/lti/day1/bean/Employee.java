package com.lti.day1.bean;

public class Employee {

	//employeeId,emp_nm,emp_sal,dept_nm,deptId
	
	private String employeeId;
	private String employeeName;
	private String deptName;
	private String deptId;
	private static Employee employee;
	private Employee employee2;
	private float employeeSalary;
	
	private Employee(String empid,String empnm) {
		employeeId=empid;
		employeeName =empnm;
	}
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	} 
	public float getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	public static Employee getInstance() {
		if(employee == null) {
			employee = new Employee("sdasd1","sada");
			return employee;
		}
		else {
			return employee;
		}
	}
	
	
}
