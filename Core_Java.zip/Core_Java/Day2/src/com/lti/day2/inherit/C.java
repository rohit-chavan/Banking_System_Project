package com.lti.day2.inherit;

public class C extends B{

}
