package com.lti.day2.inherit;

public class B extends A{

}
