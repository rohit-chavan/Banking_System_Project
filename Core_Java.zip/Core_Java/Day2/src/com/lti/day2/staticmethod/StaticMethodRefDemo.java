package com.lti.day2.staticmethod;

import java.util.function.BiFunction;

public class StaticMethodRefDemo {
	public int add(int a,int b) {
		return a+b;
	}
	public static float add(int a,float b) {
		return a+b;
	}
	public static void main(String[] args) {
		/*BiFunction<Integer,Integer,Integer> biFunction = StaticMethodRefDemo::add;
		int result = biFunction.apply(10, 20);
		System.out.println(result);*/
		StaticMethodRefDemo demo = new StaticMethodRefDemo();
		
		//provide method ref
		BiFunction<Integer, Integer, Integer> biFunction = demo::add;
		int result = biFunction.apply(20, 40);
		System.out.println(result);
	}
}
