package com.lti.EmployeeManagement.bean;

import java.sql.Date;

public class EmployeeBean {
	private String first_name;
	private String last_name;
	private Date dob;
	private Date doj;
	private float salary;
	private String designation;
	private int departmentId;
	private String registerpasswd;
	private String employeeId;
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getRegisterpasswd() {
		return registerpasswd;
	}
	public void setRegisterpasswd(String registerpasswd) {
		this.registerpasswd = registerpasswd;
	}
	@Override
	public String toString() {
		return "EmployeeBean [first_name=" + first_name + ", last_name=" + last_name + ", dob=" + dob + ", doj=" + doj
				+ ", salary=" + salary + ", designation=" + designation + ", departmentId=" + departmentId
				+ ", registerpasswd=" + registerpasswd + ", employeeId=" + employeeId + "]";
	}

	


	
}
