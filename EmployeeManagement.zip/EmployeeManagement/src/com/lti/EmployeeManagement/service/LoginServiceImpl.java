package com.lti.EmployeeManagement.service;

import com.lti.EmployeeManagement.bean.LoginBean;
import com.lti.EmployeeManagement.dao.LoginDAO;
import com.lti.EmployeeManagement.dao.LoginDAOImpl;

public class LoginServiceImpl implements LoginService{
	
	private LoginDAO dao=new LoginDAOImpl();
	@Override
	public boolean validateUser(LoginBean bean) {
		// TODO Auto-generated method stub
		return dao.validateUser(bean);
		
	}
	@Override
	public int getUserStatus(String userId) {
		// TODO Auto-generated method stub
		return dao.getUserStatus(userId);
	}
	@Override
	public String getUserType(String userId) {
		// TODO Auto-generated method stub
		
		return dao.getUserType(userId);
	}
	@Override
	public String updateUser(String userId, int status) {
		// TODO Auto-generated method stub
		return dao.updateUser(userId, status);
	}
	

}
