package com.lti.EmployeeManagement.service;

import java.util.List;

import com.lti.EmployeeManagement.bean.EmployeeBean;
import com.lti.EmployeeManagement.dao.EmployeeDAO;
import com.lti.EmployeeManagement.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService{

	private EmployeeDAO employeedao= new EmployeeDAOImpl();
	@Override
	public String addEmployee(EmployeeBean employeebean) {
		// TODO Auto-generated method stub
		return employeedao.addEmployee(employeebean);
	}

	@Override
	public List<EmployeeBean> getEmployees() {
		// TODO Auto-generated method stub
		return employeedao.getEmployees();
	}

	@Override
	public EmployeeBean getEmployeeById(String userId) {
		// TODO Auto-generated method stub
		return employeedao.getEmployeeById(userId);
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		return employeedao.deleteEmployee(userId);
	}

	@Override
	public String updateEmployee(String userId, EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		return null;
	}

}
