package com.lti.EmployeeManagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.EmployeeManagement.bean.EmployeeBean;
import com.lti.EmployeeManagement.service.EmployeeService;
import com.lti.EmployeeManagement.service.EmployeeServiceImpl;

/**
 * Servlet implementation class GetEmployeeIdServlet
 */
public class GetEmployeeIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetEmployeeIdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		EmployeeBean employeeBean = new EmployeeBean();
		String empId = request.getParameter("get_emp_text");
		employeeBean = employeeService.getEmployeeById(empId);
		RequestDispatcher dispatcher;
		/*if(employeeBean!=null) {
			 dispatcher = request.getRequestDispatcher("getemployeeid.jsp");
			 System.out.println("Employee ="+employeeBean);
				request.setAttribute("employeeBean", employeeBean);
				dispatcher.forward(request, response);
		}else {
			dispatcher = request.getRequestDispatcher("notfound.html");
		}*/
		dispatcher = request.getRequestDispatcher("getemployeeid.jsp");
		 //System.out.println("Employee ="+employeeBean);
			request.setAttribute("employeeBean", employeeBean);
			dispatcher.forward(request, response);
		
		
	}

}
