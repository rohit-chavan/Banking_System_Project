package com.lti.EmployeeManagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lti.EmployeeManagement.bean.LoginBean;
import com.lti.EmployeeManagement.service.LoginService;
import com.lti.EmployeeManagement.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService service = new LoginServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession	httpSession = null;
		String username= request.getParameter("username");
		String password = request.getParameter("password");
		
		
		System.out.println("Username:"+username+" Password:");
		/*if("admin".equals(username)&&"admin".equals(password)) {
			//request.sendRedirect("adminhome.html");
			RequestDispatcher dispatcher = request.getRequestDispatcher("adminhome.html");
			dispatcher.forward(request, response);
		}
		else {
			response.sendRedirect("home.html");
		}*/
		LoginBean bean = new LoginBean();
		bean.setPassword(password);
		bean.setUserID(username);
		
		if(service.validateUser(bean)) {
			RequestDispatcher dispatcher = null;
			//user status
			System.out.println("inside the if condti");
			if(service.getUserStatus(username)==0) {
				System.out.println("inside the user status condti");
				String res = service.getUserType(username);
				System.out.println("res valu from user status "+res);
				
				httpSession = request.getSession();
				System.out.println(httpSession.getId());
				httpSession.setAttribute("username", username);
				
				if("admin".equals(res)){
					System.out.println("inside the admin condit");
					service.updateUser(username, 1);
					dispatcher = request.getRequestDispatcher("adminhome.jsp");
					dispatcher.forward(request, response);	
					
				}
				else {
					service.updateUser(username, 1);
					dispatcher = request.getRequestDispatcher("user.jsp");
					dispatcher.forward(request, response);
				}
			}
			else if(service.getUserStatus(username)==1) {
				dispatcher = request.getRequestDispatcher("alreadylogin.html");
				dispatcher.forward(request, response);
			}
			else {
				 dispatcher = request.getRequestDispatcher("contactToAdmin.html");
				dispatcher.forward(request, response);
			}
		/*RequestDispatcher dispatcher = request.getRequestDispatcher("adminhome.html");
		dispatcher.forward(request, response);*/
		}
		else {
			response.sendRedirect("home.html");
			
		}
		
		
	}

}
