package com.lti.EmployeeManagement.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.EmployeeManagement.bean.EmployeeBean;
import com.lti.EmployeeManagement.service.EmployeeService;
import com.lti.EmployeeManagement.service.EmployeeServiceImpl;
import com.lti.EmployeeManagement.service.LoginService;
import com.lti.EmployeeManagement.service.LoginServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
public class EmployeeServletOld extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService service = new EmployeeServiceImpl();
	private EmployeeBean employeeBean = new EmployeeBean();

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServletOld() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//String empId = request.getParameter("employeeid");
		String first_nm = request.getParameter("first_name");
		String last_nm = request.getParameter("last_name");
		Float sal = new Float (request.getParameter("salary"));
		float salary=sal.floatValue();
		String design = request.getParameter("designation");
		Integer deptid_int = new Integer(request.getParameter("departmentid"));
		int deptid = deptid_int.intValue();
		String passwd = request.getParameter("registerpassword");
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date=null;
		java.util.Date date1=null;
		try {
			date = format.parse(request.getParameter("dob"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		java.sql.Date dob_date = new java.sql.Date(date.getTime());
		
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			 date1 = format.parse(request.getParameter("doj"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		java.sql.Date doj_date = new java.sql.Date(date1.getTime());
		
		
	
		/*System.out.println("empid="+empId);
		System.out.println("first_name="+first_nm);
		System.out.println("last_name="+last_nm);
		System.out.println("salary="+salary);
		System.out.println("designation="+design);
		System.out.println("depatid="+deptid);
		System.out.println("registepass="+passwd);*/
		
		employeeBean.setFirst_name(first_nm);
		employeeBean.setLast_name(last_nm);
		employeeBean.setDob(dob_date);
		employeeBean.setDoj(doj_date);
		employeeBean.setSalary(salary);
		employeeBean.setDesignation(design);
		employeeBean.setDepartmentId(deptid);
		employeeBean.setRegisterpasswd(passwd);
		System.out.println(employeeBean);
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		String result = employeeService.addEmployee(employeeBean);
		System.out.println(result);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
