package com.lti.EmployeeManagement.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeUtils {

	public static String generateEmployeeId(String firstname) {
		
		String query = "select emp_seq.nextval as id from dual";
		Connection connection = Db_Utils.getConnection();
		ResultSet resultSet = null;
		String res =null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				res = resultSet.getString(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "fail";
		}
		finally {
			Db_Utils.close(connection);
		}
		return firstname.substring(0, 2).concat(res);
	}
}
