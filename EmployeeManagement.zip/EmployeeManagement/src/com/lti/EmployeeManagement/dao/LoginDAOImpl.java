package com.lti.EmployeeManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.lti.EmployeeManagement.bean.LoginBean;
import com.lti.EmployeeManagement.util.Db_Utils;

public class LoginDAOImpl implements LoginDAO{

	@Override
	public boolean validateUser(LoginBean bean) {
		// TODO Auto-generated method stub
		System.out.println(bean);
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement("select * from login where userID=? and password=?");
			preparedStatement.setString(1, bean.getUserID());
			preparedStatement.setString(2, bean.getPassword());
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				System.out.println("inside the result set");
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		finally {
			Db_Utils.close(connection);
		}
		return false;
	}
        
	@Override
	public String updateUser(String userId, int status) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		//ResultSet resultSet = null;
		int resultrow = 0;
		String query = "update login set status = ? where userID = ?";
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,status);
			preparedStatement.setString(2, userId);
			resultrow = preparedStatement.executeUpdate();
			
				connection.commit();
				return "success";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		return null;
	}

	@Override
	public int getUserStatus(String userId) {
		// TODO Auto-generated method stub
		String query = "select status from login where userID = ?";
		
		Connection connection = Db_Utils.getConnection();
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);		//1-> ? sequence
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				int res =  resultSet.getInt(1);	
				System.out.println(res);
				// 1 -> column sequence
				return res;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		return 0;
	}

	@Override
	public String getUserType(String userId) {
		// TODO Auto-generated method stub.
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		String query="select usertype from login where userID = ?";
		Connection connection = Db_Utils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				return resultSet.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		return null;
	}

	@Override
	public String insertRecordLogin(LoginBean loginbean) {
		// TODO Auto-generated method stub
		String query = "insert into login values(?,?,'user',0)";
		PreparedStatement preparedStatement = null;
		Connection connection = Db_Utils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, loginbean.getUserID());
			System.out.println("hello from "+loginbean.getUserID());
			
			preparedStatement.setString(2, loginbean.getPassword());
			int insertresultlogin = preparedStatement.executeUpdate();
			if (insertresultlogin==1) {
				connection.commit();
				return "success";
			}
			else {
				return "fail";
			}

		} catch (SQLException e) {
			System.out.println("ueghuwehguh");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);

		}
		
		return null;
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		String query = "delete from login where USERID = ?";
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);
			int login_del_res = preparedStatement.executeUpdate();
			if(login_del_res==1) {
				connection.commit();
				return "deletedlogin";
			}
			else {
				return "deletefail";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			Db_Utils.close(connection);

		}
		return null;
	}
	

}
