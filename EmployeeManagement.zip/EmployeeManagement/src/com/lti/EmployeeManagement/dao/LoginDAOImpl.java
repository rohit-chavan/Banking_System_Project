package com.lti.EmployeeManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.lti.EmployeeManagement.bean.LoginBean;
import com.lti.EmployeeManagement.util.Db_Utils;

public class LoginDAOImpl implements LoginDAO{

	@Override
	public boolean validateUser(LoginBean bean) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement("select * from login where userID=? and password=?");
			preparedStatement.setString(1, bean.getUserID());
			preparedStatement.setString(2, bean.getPassword());
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		finally {
			Db_Utils.close(connection);
		}
		return false;
	}

	@Override
	public String updateUser(String userID, int status) {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public int getUserStatus(String userId) {
		// TODO Auto-generated method stub
		String query = "select status from login where userID = ?";
		
		Connection connection = Db_Utils.getConnection();
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);		//1-> ? sequence
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				return resultSet.getInt(1);			// 1 -> column sequence
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		return 0;
	}

	@Override
	public String getUserType(String userId) {
		// TODO Auto-generated method stub.
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		String query="select usertype from login where userID = ?";
		Connection connection = Db_Utils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userId);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				return resultSet.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		return null;
	}


}
