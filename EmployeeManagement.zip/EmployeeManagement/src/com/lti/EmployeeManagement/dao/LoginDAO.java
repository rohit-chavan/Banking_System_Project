package com.lti.EmployeeManagement.dao;

import com.lti.EmployeeManagement.bean.LoginBean;

public interface LoginDAO {
	
	public boolean validateUser(LoginBean bean); 
	
	public String updateUser(String userId, int status);
	
	public int getUserStatus(String userId);
	
	public String getUserType(String userId);
	
	public String insertRecordLogin(LoginBean loginbean);
	
	public String deleteEmployee(String userId);
		
	
		
}

