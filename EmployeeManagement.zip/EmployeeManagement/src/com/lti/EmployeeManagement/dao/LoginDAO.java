package com.lti.EmployeeManagement.dao;

import com.lti.EmployeeManagement.bean.LoginBean;

public interface LoginDAO {
	
	public boolean validateUser(LoginBean bean); 
	
	public String updateUser(String userID, int status);
	
	public int getUserStatus(String userId);
	
	public String getUserType(String userId);
	
	
		
}

