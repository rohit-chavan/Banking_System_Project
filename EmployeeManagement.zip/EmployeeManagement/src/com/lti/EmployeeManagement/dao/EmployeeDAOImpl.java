package com.lti.EmployeeManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.EmployeeManagement.bean.EmployeeBean;
import com.lti.EmployeeManagement.bean.LoginBean;
import com.lti.EmployeeManagement.util.Db_Utils;
import com.lti.EmployeeManagement.util.EmployeeUtils;

public class EmployeeDAOImpl implements EmployeeDAO{
	
	EmployeeBean empbean = new EmployeeBean();

	@Override
	public String addEmployee(EmployeeBean employeebean) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		String query = "insert into empl values(?,?,?,?,?,?,?,?)";
		try {
			preparedStatement = connection.prepareStatement(query);
			String id = EmployeeUtils.generateEmployeeId(employeebean.getFirst_name());
			//String generateId = EmployeeUtils.generateEmployeeId(firstname);
			preparedStatement.setString(1,id);
			preparedStatement.setString(2, employeebean.getFirst_name());
			preparedStatement.setString(3, employeebean.getLast_name());
			preparedStatement.setDate(4, employeebean.getDob());
			preparedStatement.setDate(5, employeebean.getDoj());
			preparedStatement.setFloat(6, employeebean.getSalary());
			preparedStatement.setString(8, employeebean.getDesignation());
			preparedStatement.setInt(7, employeebean.getDepartmentId());

			int insertresultrow = preparedStatement.executeUpdate();
			if (insertresultrow==1) {
				LoginDAOImpl daoImpl = new LoginDAOImpl();
				LoginBean loginBean = new LoginBean();
				loginBean.setPassword(employeebean.getRegisterpasswd());
				loginBean.setUserID(id);
				System.out.println(employeebean.getEmployeeId());
				daoImpl.insertRecordLogin(loginBean);
				connection.commit();
				return "success";
			}
			else {
				return "fail";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}

		return null;
	}

	@Override
	public List<EmployeeBean> getEmployees() {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		int i=0;
		ResultSet resultSet = null;
		String query = "select * from empl";
		ArrayList<EmployeeBean> arrayList =  new ArrayList<>(); 

		try {
			preparedStatement=connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				EmployeeBean empbean = new EmployeeBean();
				
				empbean.setEmployeeId(resultSet.getString(1));
				empbean.setFirst_name(resultSet.getString(2));
				empbean.setLast_name(resultSet.getString(3));
				empbean.setDob(resultSet.getDate(4));
				empbean.setDoj(resultSet.getDate(5));
				empbean.setSalary(resultSet.getFloat(6));
				empbean.setDepartmentId(resultSet.getInt(7));
				empbean.setDesignation(resultSet.getString(8));
				
				arrayList.add(empbean);			
				
				
				
			}
			System.out.println(arrayList);
			return arrayList;
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return null;
	}

	@Override
	public EmployeeBean getEmployeeById(String userId) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		String query = "select * from empl where EMPLOYEEID=?";
		try {
			preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1, userId);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				connection.commit();
				EmployeeBean empbean1 = new EmployeeBean();
				empbean1.setEmployeeId(resultSet.getString(1));
				empbean1.setFirst_name(resultSet.getString(2));
				empbean1.setLast_name(resultSet.getString(3));
				empbean1.setDob(resultSet.getDate(4));
				empbean1.setDoj(resultSet.getDate(5));
				empbean1.setSalary(resultSet.getFloat(6));
				empbean1.setDepartmentId(resultSet.getInt(7));
				empbean1.setDesignation(resultSet.getString(8));
				
				return empbean1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		return null;
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		int delete_result;
		System.out.println("hello from delete method");
		String query = "delete from empl where EMPLOYEEID = ?";
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,userId);
			delete_result = preparedStatement.executeUpdate();
			System.out.println("DeleteResult"+delete_result);
			if(delete_result==1) {
				LoginDAOImpl daoImpl_del = new LoginDAOImpl();
				daoImpl_del.deleteEmployee(userId);
				connection.commit();
				return "success";
			}
			else {
				return "fail";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		
		
		return null;
	}

	@Override
	public String updateEmployee(String userId, EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		return null;
	}

}
