package com.lti.EmployeeManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.lti.EmployeeManagement.bean.EmployeeBean;
import com.lti.EmployeeManagement.bean.LoginBean;
import com.lti.EmployeeManagement.util.Db_Utils;
import com.lti.EmployeeManagement.util.EmployeeUtils;

public class EmployeeDAOImpl implements EmployeeDAO{

	@Override
	public String addEmployee(EmployeeBean employeebean) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		String query = "insert into empl values(?,?,?,?,?,?,?,?)";
		try {
			preparedStatement = connection.prepareStatement(query);
			String id = EmployeeUtils.generateEmployeeId(employeebean.getFirst_name());
			//String generateId = EmployeeUtils.generateEmployeeId(firstname);
			preparedStatement.setString(1,id);
			preparedStatement.setString(2, employeebean.getFirst_name());
			preparedStatement.setString(3, employeebean.getLast_name());
			preparedStatement.setDate(4, employeebean.getDob());
			preparedStatement.setDate(5, employeebean.getDoj());
			preparedStatement.setFloat(6, employeebean.getSalary());
			preparedStatement.setString(8, employeebean.getDesignation());
			preparedStatement.setInt(7, employeebean.getDepartmentId());

			int insertresultrow = preparedStatement.executeUpdate();
			if (insertresultrow==1) {
				LoginDAOImpl daoImpl = new LoginDAOImpl();
				LoginBean loginBean = new LoginBean();
				loginBean.setPassword(employeebean.getRegisterpasswd());
				loginBean.setUserID(id);
				System.out.println(employeebean.getEmployeeId());
				daoImpl.insertRecordLogin(loginBean);
				connection.commit();
				return "success";
			}
			else {
				return "fail";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}

		return null;
	}

	@Override
	public List<EmployeeBean> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeBean getEmployeeById(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		Connection connection = Db_Utils.getConnection();
		PreparedStatement preparedStatement=null;
		int delete_result;
		System.out.println("hello from delete method");
		String query = "delete from empl where EMPLOYEEID = ?";
		try {
			System.out.println("hello from shree");
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,userId);
			delete_result = preparedStatement.executeUpdate();
			System.out.println("DeleteResult"+delete_result);
			if(delete_result==1) {
				LoginDAOImpl daoImpl_del = new LoginDAOImpl();
				daoImpl_del.deleteEmployee(userId);
				connection.commit();
				return "success";
			}
			else {
				return "fail";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			Db_Utils.close(connection);
		}
		
		
		return null;
	}

	@Override
	public String updateEmployee(String userId, EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		return null;
	}

}
