package com.lti.HibernateDemo.main;

import java.util.List;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.lti.HibernateDemo.bean.Order;
import com.lti.HibernateDemo.bean.ProductBean;
import com.lti.HibernateDemo.service.ProductService;
import com.lti.HibernateDemo.service.ProductServiceImpl;
import com.lti.HibernateDemo.util.Hibernate_Utils;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = Hibernate_Utils.getSessionFactory();
		Session session = sessionFactory.openSession();
		ProductService productService = new ProductServiceImpl();
		List<ProductBean> list = new ArrayList<>();
		ProductBean productBean = new ProductBean();
		session.beginTransaction();
		/*Order order = new Order();
		Date dt = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat();
		order.setOrderId("ab001");
		order.setProductId("pr1");
		order.setDeliveryDate(dt);*/
		/*productBean.setProd_id("pr103");
		productBean.setProd_nm("afdg");
		productBean.setProd_price(5000f);
		productBean.setProd_quantity(1);
		String result = productService.addProduct(productBean);
	System.out.println(result);*/

		list = productService.getProducts();
		for(ProductBean bean: list) {
				System.out.println(bean);
		}
		//session.save(productBean);
		session.getTransaction().commit();
		Hibernate_Utils.closeSessionFactory(sessionFactory);
		Query query = session.getNamedQuery("query1");
		query.setParameter("id", "pr104");
		List<ProductBean> list1 = query.list();
		for (ProductBean productBean2 : list1) {
			System.out.println(productBean2);
			    
		}
		
		
				
		
		
		/*bean.setProd_id("pr102");
		productService.deleteProduct(bean);*/
		//ProductBean bean2 = new ProductBean();
		//bean2.setProd_id("pr101");
		/*bean2 = productService.getProductById("pr105");
		System.out.println(bean2);*/
	}

}
