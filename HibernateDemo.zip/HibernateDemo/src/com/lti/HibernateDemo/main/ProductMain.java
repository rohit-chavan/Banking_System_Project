package com.lti.HibernateDemo.main;

import org.dom4j.bean.BeanAttribute;
import org.hibernate.SessionFactory;

import com.lti.HibernateDemo.DAO.ProductDao;
import com.lti.HibernateDemo.bean.ProductBean;
import com.lti.HibernateDemo.service.ProductService;
import com.lti.HibernateDemo.service.ProductServiceImpl;
import com.lti.HibernateDemo.util.Hibernate_Utils;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = Hibernate_Utils.getSessionFactory();
		Hibernate_Utils.closeSessionFactory(sessionFactory);
		ProductBean bean = new ProductBean();
		ProductService productService = new ProductServiceImpl();
		bean.setProd_id("pr104");
		bean.setProd_nm("adsad");
		bean.setProd_price(2500f);
		bean.setProd_quantity(2);
		String result = productService.addProduct(bean);
	System.out.println(result);
		/*bean.setProd_id("pr102");
		productService.deleteProduct(bean);*/
		//ProductBean bean2 = new ProductBean();
		//bean2.setProd_id("pr101");
		/*bean2 = productService.getProductById("pr105");
		System.out.println(bean2);*/
	}

}
