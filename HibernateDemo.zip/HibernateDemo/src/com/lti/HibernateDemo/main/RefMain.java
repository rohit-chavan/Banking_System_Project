package com.lti.HibernateDemo.main;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lti.HibernateDemo.bean.Order;
import com.lti.HibernateDemo.bean.ProductBean;
import com.lti.HibernateDemo.util.Hibernate_Utils;

public class RefMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = Hibernate_Utils.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		ProductBean bean = new ProductBean();
		bean.setProd_nm("sdad");
		bean.setProd_price(221f);
		bean.setProd_quantity(5);
		session.save(bean);
		Order order = new Order();
		order.setOrderName("abc");
		Order order2 = new Order();
		order2.setOrderName("pqr");
		
		order.setProductBean(bean);
		order2.setProductBean(bean);
		session.save(order);
		session.save(order2);
		transaction.commit();
		session.close();
	}

}
