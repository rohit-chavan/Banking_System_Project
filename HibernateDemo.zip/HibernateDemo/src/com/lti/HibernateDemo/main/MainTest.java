package com.lti.HibernateDemo.main;

import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.lti.HibernateDemo.util.Hibernate_Utils;

public class MainTest {
	public static void main(String[] args) {
		
	SessionFactory sessionFactory = Hibernate_Utils.getSessionFactory();
	Session session = sessionFactory.openSession();
			String query = "select prod_id ,prod_nm ,prod_price from ProductBean";
			Query query2 =session.createQuery(query);
			//List<Map<String,String>> list = query2.list();
			/*for (Map<String, String> map : list) {
				System.out.println(map);
				
			}*/
			/*List<Object[]> list = query2.list();
			for (Object[] objects : list) {
				for (Object object : objects) {
					System.out.print(object+"\t");
				}
				System.out.println();
			}*/
			
			
	}
}
