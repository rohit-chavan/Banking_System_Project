package com.lti.HibernateDemo.main;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory; 
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.lti.HibernateDemo.bean.ProductBean;
import com.lti.HibernateDemo.util.Hibernate_Utils;

public class MainTest2 {
	public static void main(String[] args) {
		SessionFactory sessionFactory = Hibernate_Utils.getSessionFactory();
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(ProductBean.class);
		List<ProductBean> list = criteria.addOrder(Order.asc("prod_id")).list();
		
		for (ProductBean productBean : list) {
			System.out.println(productBean);
			
		}
	}
}
