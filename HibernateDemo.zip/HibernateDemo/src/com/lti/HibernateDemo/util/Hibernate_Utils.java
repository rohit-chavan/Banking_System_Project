package com.lti.HibernateDemo.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class Hibernate_Utils {
	public static SessionFactory getSessionFactory() {
		return new AnnotationConfiguration().configure().buildSessionFactory();
		
		
		
	}
	public static void closeSessionFactory(SessionFactory sessionFactory) {
		sessionFactory.close();
	}
	
}
