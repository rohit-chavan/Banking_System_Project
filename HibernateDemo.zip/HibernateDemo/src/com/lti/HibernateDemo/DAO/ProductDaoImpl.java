package com.lti.HibernateDemo.DAO;

import java.sql.PreparedStatement;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lti.HibernateDemo.bean.ProductBean;
import com.lti.HibernateDemo.util.Hibernate_Utils;

public class ProductDaoImpl implements ProductDao {
	private final SessionFactory sessionFactory=Hibernate_Utils.getSessionFactory();

	@Override
	public String addProduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.persist(productBean);
		transaction.commit();
		session.close();
		return "success";
	}

	@Override
	public List<ProductBean> getProducts() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		
		try {
		String query = "from ProductBean where PROD_ID = ?";
		Query query2 = session.createQuery(query);
		query2.setString(0,"pr108");
		return query2.list();
		}catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		finally {
			
			session.close();
		}
	}

	@Override
	public ProductBean getProductById(String productId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		ProductBean productBean = (ProductBean) session.load(ProductBean.class, productId);
		
		transaction.commit();
		//session.close();
		return productBean;
		
		
	}

	@Override
	public String deleteProduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.evict(productBean);
		transaction.commit();
		session.close();
		return "deleted";
		
	
	}

	@Override
	public String updateProduct(String productId, ProductBean productBean) {
		// TODO Auto-generated method stub
		return null;
	}

}
