package com.lti.HibernateDemo.DAO;

import java.util.List;

import com.lti.HibernateDemo.bean.ProductBean;

public interface ProductDao {
	public String addProduct(ProductBean productBean);
	public List<ProductBean> getProducts();
	public ProductBean getProductById(String productId);
	public String deleteProduct(ProductBean productBean);
	public String updateProduct(String productId,ProductBean productBean);
}
