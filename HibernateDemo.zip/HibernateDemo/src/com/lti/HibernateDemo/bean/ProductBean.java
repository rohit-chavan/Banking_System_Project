package com.lti.HibernateDemo.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class ProductBean {
	@Override
	public String toString() {
		return "ProductBean [prod_id=" + prod_id + ", prod_nm=" + prod_nm + ", prod_price=" + prod_price
				+ ", prod_quantity=" + prod_quantity + "]";
	}
	@Id
	private String prod_id;
	private String prod_nm;
	
	private float prod_price;
	
	private int prod_quantity;
	public int getProd_quantity() {
		return prod_quantity;
	}
	public void setProd_quantity(int prod_quantity) {
		this.prod_quantity = prod_quantity;
	}
	
	public String getProd_id() {
		return prod_id;
	}
	public void setProd_id(String prod_id) {
		this.prod_id = prod_id;
	}
	public String getProd_nm() {
		return prod_nm;
	}
	public void setProd_nm(String prod_nm) {
		this.prod_nm = prod_nm;
	}
	public float getProd_price() {
		return prod_price;
	}
	public void setProd_price(float prod_price) {
		this.prod_price = prod_price;
	}
	
	
}
