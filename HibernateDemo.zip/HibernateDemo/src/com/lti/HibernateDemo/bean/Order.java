package com.lti.HibernateDemo.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity (name="Order")
@Table (name="Order111")

public class Order {
	
	@Id 
	@GeneratedValue(strategy= GenerationType.AUTO)
	@Column(name="orderId")
	private String orderId;
	/*@Column(name="productId" )
	
	private String productId;*/
	@ManyToOne
	@JoinColumn(name="product_id")
	private ProductBean productBean;
	private String orderName;
	private Date orderDate;
	private Date deliveryDate;
	
	public ProductBean getProductBean() {
		return productBean;
	}
	public void setProductBean(ProductBean productBean) {
		this.productBean = productBean;
	}
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/*public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}*/
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	
}
