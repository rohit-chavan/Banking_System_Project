package com.lti.HibernateDemo.service;

import java.util.List;

import com.lti.HibernateDemo.DAO.ProductDao;
import com.lti.HibernateDemo.DAO.ProductDaoImpl;
import com.lti.HibernateDemo.bean.ProductBean;

public class ProductServiceImpl implements ProductService{
	
	ProductDao dao = new ProductDaoImpl();
	@Override
	public String addProduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		return dao.addProduct(productBean);
	}

	@Override
	public List<ProductBean> getProducts() {
		// TODO Auto-generated method stub
		return dao.getProducts();
	}

	@Override
	public ProductBean getProductById(String productId) {
		// TODO Auto-generated method stub
		return dao.getProductById(productId);
	}

	@Override
	public String deleteProduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		return dao.deleteProduct(productBean);
	}

	@Override
	public String updateProduct(String productId, ProductBean productBean) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
