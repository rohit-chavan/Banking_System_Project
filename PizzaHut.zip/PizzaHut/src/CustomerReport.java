


public class CustomerReport {
	private Customer custList[] = new Customer[5];
	public static int count=0;
	
	public String addCustomer(Customer customer) {
		if(custList.length<=count) {
			return "array full";
		}else {
			custList[count]=customer;
			count++;
			return "Customer successfully added";
		}
		
	}
	public Customer printList() {
		for (Customer customer : custList) {
			return customer;
		}
		return null;
}
	
	public Customer getCustomer(int id) {
		for (int i = 0; i < custList.length; i++) {
			Customer customer = custList[i];
			return customer;
		}
		return null;
	}
	
}

