
public class Customer {
	private int custNo;
	private String custName;
	private String custAddr;
	Customer(int custNo,String custName,String custAddr){
		this.custNo=custNo;
		this.custName=custName;
		this.custAddr=custAddr;
	}
	@Override
	public String toString() {
		return "Customer [custNo=" + custNo + ", custName=" + custName + ", custAddr=" + custAddr + "]";
	}
	public int getCustNo() {
		return custNo;
	}
	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustAddr() {
		return custAddr;
	}
	public void setCustAddr(String custAddr) {
		this.custAddr = custAddr;
	}
	
	
	/*private void init() {
		custNo = 101;
		custName = "Tyler";
		custAddr = "Los Angeles";
	}*/
	
	/*private void display() {
		System.out.println("CustomerNo="+custNo);
		System.out.println("CustomerName="+custName);
		System.out.println("CustomerAddress="+custAddr);
	}*/
	
	
}
