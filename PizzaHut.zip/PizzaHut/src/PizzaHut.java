import java.util.Scanner;

public class PizzaHut {
	public static void main(String[] args) {
		Customer customer = new Customer(101,"Tyler","TwentyOnePilots");
		Customer customer2 = new Customer(102, "Mark", "Egypt");
		Customer customer3 = new Customer(103, "CRA", "Mkj");
		Customer customer4 = new Customer(104, "VHH", "FCH");
		Customer customer5 = new Customer(105, "SWWD", "DJEF");
		CustomerReport customerReport= new CustomerReport();
		String result = customerReport.addCustomer(customer);
		System.out.println(result);
		//System.out.println(customerReport.printList());
		String result2 = customerReport.addCustomer(customer2);
		System.out.println(result2);
		//System.out.println(customerReport.printList());
		//System.out.println(customerReport.getCustomer(102));
		customerReport.addCustomer(customer3);
		customerReport.addCustomer(customer4);
		customerReport.addCustomer(customer5);
		System.out.println(customerReport.printList());
		
		/*customer.setCustNo(101);
		customer.setCustName("Tyler");
		customer.setCustAddr("TwentyonePilot");
		System.out.println("Using getter and setters");
		System.out.println("CustomerNo"+customer.getCustNo());
		System.out.println("CustomerName"+customer.getCustName());
		System.out.println("CustomerAddress"+customer.getCustAddr());*/
		
	}
}
