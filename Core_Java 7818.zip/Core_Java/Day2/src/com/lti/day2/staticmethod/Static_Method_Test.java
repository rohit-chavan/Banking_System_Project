package com.lti.day2.staticmethod;

import java.util.ArrayList;

public class Static_Method_Test {
	public static int count=0;
	
	public static void testmethod() {
		System.out.println(count);
	}
	
	
	public static void main(String[] args) {
		ArrayList <String> list = new ArrayList <>();
		list.add("abhi");
		list.add("shreer");
		list.add("anthy");
		list.forEach(System.out::println);
		Static_Method_Test.testmethod();
		Static_Method_Test static_Method_Test = new Static_Method_Test();
		static_Method_Test.testmethod();
	}

}
