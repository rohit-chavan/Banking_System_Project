package com.lti.day2.inherit;

public class A {
	
	public A() {
	}

}
