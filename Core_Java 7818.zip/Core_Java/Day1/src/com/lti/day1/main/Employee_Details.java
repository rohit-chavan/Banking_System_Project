package com.lti.day1.main;

import com.lti.day1.bean.Employee;

public class Employee_Details {
	public static void main(String[] args) {
		
		Employee employee = Employee.getInstance();
		System.out.println("EmployeeId :"+employee.getEmployeeId());
		
		employee.setEmployeeId("ab20");
		System.out.println("Setter Empid:"+employee.getEmployeeId());
	
		Employee employee2 = Employee.getInstance();
		System.out.println("Common value:"+employee.getEmployeeId());
		
	}
}
