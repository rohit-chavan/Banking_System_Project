package com.lti.treesetproj.util;

import java.util.Comparator;

import com.lti.tresesetproj.service.Employee;

public class EmployeeIdComparator implements Comparator{

	@Override
	public int compare(Object arg0, Object arg1) {
		Employee employee = (Employee) arg0;
		Employee employee2 = (Employee) arg1;
		System.out.println("util pkg compare");
		
		return employee.getEmployeeId().compareTo(employee2.getEmployeeId());
		
	}
	
	
	
	

}
