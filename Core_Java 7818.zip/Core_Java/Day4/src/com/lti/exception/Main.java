package com.lti.exception;

import java.io.IOException;
import com.lti.exception.*;

public class Main{


	/*public static void Excptn() throws IOException,NullPointerException{
    
	}*/
	
	
	public static void main(String[] args){
		int age=10;
		
		if(age<16) {
			
			try {
				throw new AgeLimitException("underage");
			} catch (AgeLimitException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			System.out.println("Eligible");
		}
	
	//Main.Excptn();
	 /*try {
		// System.out.println(a/b);
		 //throw new ArithmeticException();
		 //Main.Excptn();
	 }
	 /*catch(Exception e) {
		 
		 System.out.println("Exception caught");
	 }*/
	//catch(Exception ea) {
		// System.out.println("In Main method");
		 //throw new ArithmeticException();
	 }
	 /*finally {
		 System.out.println("inside finally");
		 return ; 
	 }*/
	
	
		
	}

