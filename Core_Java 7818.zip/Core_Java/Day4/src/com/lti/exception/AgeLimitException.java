package com.lti.exception;

public class AgeLimitException extends Exception {
	@Override
	
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	public AgeLimitException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
