package com.lti.tresesetproj.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class EmployeeMapServiceImpl implements  EmployeeMapService{
	
	HashMap<Employee, String> hashMap = new HashMap<>();

	@Override
	public String add(Employee key, String value) {
		hashMap.put(key, value);
		return "success";
	}

	@Override
	public void display() {
		//1.by calling keysets & values method
		//2.by calling entryset
		/*Set<Employee> set = hashMap.keySet();
		List<String> list = new ArrayList<String>(hashMap.values());
		Iterator<Employee> iterator = set.iterator();
		
		int i = 0 ;
		while(iterator.hasNext()) {
			Employee employee = (Employee) iterator.next();
			System.out.println(employee +list.get(i));
			i++;
		}*/
		
		Set<Entry<Employee,String>> set = hashMap.entrySet();
		
		Iterator<Entry<Employee,String>> iterator = set.iterator();
		
		while (iterator.hasNext()) {
			Map.Entry<com.lti.tresesetproj.service.Employee, java.lang.String> entry = (Map.Entry<com.lti.tresesetproj.service.Employee, java.lang.String>) iterator
					.next();
			
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
		
	}

	

}
