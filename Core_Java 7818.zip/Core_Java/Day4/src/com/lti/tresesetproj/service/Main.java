package com.lti.tresesetproj.service;

import java.util.List;
import java.util.TreeSet;

import com.lti.treesetproj.util.EmployeeIdComparator;

public class Main {
	
	public static void main(String arg[]) {
		EmployeeService service = new EmployeeServiceImpl();
		
		Employee employee = new Employee("ab001", "shree");
		String result=service.addEmployee(employee);
		//adding duplicates value
		String result2= service.addEmployee(employee);
		System.out.println(result);
		System.out.println(result2);
		Employee employee2= new Employee("ac020","shre");
		String result3 = service.addEmployee(employee2);
		System.out.println(result3);
		//String resdel = service.deleteEmployee("ab001"); 
		List<Employee> list = service.getEmployees();
		list.forEach(System.out::println);
		System.out.println(service.getEmployeeById("ab001"));
		
		TreeSet treeSet = new TreeSet<>();
		
		//Class EmployeeIdComparator
		EmployeeIdComparator employeeIdComparator = new EmployeeIdComparator();
		int op = employeeIdComparator.compare(employee, employee2);
		System.out.println(op);
		
		/*treeSet.add(10);
		treeSet.add("shree");
		treeSet.add(employee);
		System.out.println(treeSet);*/
	}

}
