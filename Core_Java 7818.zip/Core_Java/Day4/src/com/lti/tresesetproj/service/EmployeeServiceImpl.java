package com.lti.tresesetproj.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.lti.treesetproj.util.EmployeeIdComparator;


public class EmployeeServiceImpl implements EmployeeService{
	
	private TreeSet<Employee> empTreeSet = new TreeSet<>(new EmployeeIdComparator());

	@Override
	public String addEmployee(Employee employee) {
		try {
			if(empTreeSet.add(employee)) {
				return "success";
			}
			else {
				return "fail";
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return null;
	}

	@Override
	public Employee getEmployeeById(String id) {
		Iterator<Employee> iterator = empTreeSet.iterator();
		while (iterator.hasNext()) {
			Employee employee = (Employee) iterator.next();
			if (employee.getEmployeeId().equals(id)) {
				return employee;
			}
		//return null;
	}
		return null;		//To remove null value from o/p use optional class
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return new ArrayList<Employee>(empTreeSet);
		//return null;
	}

	@Override
	public String deleteEmployee(String id) {
		Optional <Employee> optional = empTreeSet.stream().filter(emp1 -> id.equals(emp1.getEmployeeId())).findFirst();
		if(optional.isPresent()) {
			//Employee employee = optional.get();
			empTreeSet.remove(optional.get());		//optional.get->to get Employee object /(employee)/
			System.out.println("Deleted");
		}
		else {
			System.out.println("Not Deleted");
		}
		return null;
	}

	@Override
	public String updateEmployee(String id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
