package com.lti.tresesetproj.service;

public class MapMain {
	public static void main(String[] args) {
		EmployeeMapService service = new EmployeeMapServiceImpl();
		Employee key  = new Employee("ab001","abhi");
		service.add(key, "hello");
		service.add(key, "hello");
		Employee key2 = new Employee("ab002","abhi");
		service.add(key2, "hello");
		service.display();
			
	}

}  `
