package com.lti.tresesetproj.service;

public interface EmployeeMapService {
	
	public String add(Employee key, String value);
	public void display();
	
}
