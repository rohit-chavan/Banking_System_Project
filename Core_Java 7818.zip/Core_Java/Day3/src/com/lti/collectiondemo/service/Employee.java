package com.lti.collectiondemo.service;

public class Employee {

	//employeeId,emp_nm,emp_sal,dept_nm,deptId
	
	private String employeeId;
	private String employeeName;
	private String deptName;
	private String deptId;
	private Employee employee;
	//private Employee employee2;
	private float employeeSalary;
	public float net_sal;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((employeeId == null) ? 0 : employeeId.hashCode());
		result = prime * result + ((employeeName == null) ? 0 : employeeName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeId == null) {
			if (other.employeeId != null)
				return false;
		} else if (!employeeId.equals(other.employeeId))
			return false;
		if (employeeName == null) {
			if (other.employeeName != null)
				return false;
		} else if (!employeeName.equals(other.employeeName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + "]";
	}

	public Employee(String employeeId,String employeeName) {
		this.employeeId=employeeId;
		this.employeeName = employeeName;
	}
	
	/*public Employee() {
		System.out.println("Constructor Base");
	}*/
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	} 
	public float getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	//employee = new Employee("sdasd1","sada");	
	/*public static Employee getInstance() {
		if(employee == null) {
			employee = new Employee("sdasd1","sada");
			return employee;
		}
		else {
			return employee;
		}*/
	//}
	
	  float calculateSalary() {
		float net_sal=0;
		float hra = this.employeeSalary*0.1f;
		float ta = this.employeeSalary*0.1f;
		float da= this.employeeSalary*0.1f;
		net_sal= this.employeeSalary+hra+ta+da;
		return net_sal;
		
	}
	
	
}
