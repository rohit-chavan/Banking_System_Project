package com.lti.collectiondemo.service;


import java.util.List;
import java.util.Optional;

public interface EmployeeService {
	
	public String addEmployee(Employee employee);
	public Employee getEmployeeById(String id);
	public List<Employee> getEmployees();
	public String deleteEmployee(String id);
	public String updateEmployee(String id,Employee employee); 
	
}
