package com.lti.collectiondemo.service;

import java.util.Optional;

public class Test {
	public static void main(String[] args) {
		//Employee emp = new Manager();
		Employee employee = new Employee("101","nma");
		Employee emp1 = new Employee("102", "name");
		Employee emp2 = new Employee("105","ggg");
		//Employee emp2 = new Employee("101","nma"); 
		/*Employee e3 = emp2;
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		System.out.println(emp1.equals(emp2));
		System.out.println(e3.equals(emp2));
		System.out.println(e3.hashCode());
		System.out.println(emp1.toString());*/
		EmployeeServiceImpl employeeServiceImpl = new EmployeeServiceImpl();
		String result= employeeServiceImpl.addEmployee(employee);
		String result1= employeeServiceImpl.addEmployee(emp1);
		String res = employeeServiceImpl.addEmployee(emp2);
		System.out.println(result);
		//System.out.println(result1);
		//System.out.println(employeeServiceImpl.getEmployeeById("105"));
		//System.out.println(employeeServiceImpl.getEmployeeById("103"));
		//employeeServiceImpl.getEmployeeById("101");
		//employeeServiceImpl.deleteEmployee("101");
		//employeeServiceImpl.getEmployeeById("101");
		//employeeServiceImpl.getEmployeeById("101");
		//employeeServiceImpl.getEmployees();
		employeeServiceImpl.updateEmployee("101", emp2);
		System.out.println(employeeServiceImpl.getEmployees());

		//System.out.println(employeeServiceImpl);

		
		
		
		/*Manager mgr = new Manager();
		mgr.setEmployeeSalary(10000);
		mgr.setEmployeeId("ab001");
		mgr.setEmployeeName("abhi");
		mgr.setDeptId("10");
		mgr.setProjectAllowance(5000);
		mgr.calculateSalary();
		
		
		System.out.println("..Added");
		
		//System.out.println(mgr.getEmployeeId());
		//System.out.println(mgr.getEmployeeName());
		//System.out.println(mgr.getDeptId());
		System.out.println("Project Allowance="+mgr.getProjectAllowance());
		System.out.println("ManagerSalary="+mgr.net_sal);
	}*/
	
	}
}
