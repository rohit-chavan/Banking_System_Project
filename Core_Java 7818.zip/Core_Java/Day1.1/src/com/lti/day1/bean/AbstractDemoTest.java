package com.lti.day1.bean;

public class AbstractDemoTest {
	public static void display(Employee employee) {
		float result= employee.calculateSalary();
		System.out.println(result);
	}
	
	public static void main(String[] args) {
		AbstractDemoTest.display(new Manager());
		
		/*AbstractDemo demo = new Derived();
		Derived derived = (Derived) demo;
		derived.sample();
		demo.test();
		demo.show();*/
	}

}
