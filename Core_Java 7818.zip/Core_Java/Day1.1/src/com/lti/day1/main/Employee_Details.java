package com.lti.day1.main;

import java.util.Scanner;

import com.lti.day1.bean.Employee;
import com.lti.day1.service.Employee_Service;

public class Employee_Details {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Employee_Service employeeservice = new Employee_Service();
		boolean status=true;
		String id;
		String name;
		int choice;
		
		while(status) {
			System.out.println("Enter ur choice:");
			System.out.println("1.Add Employees");
			System.out.println("2.Get EMployees");
			System.out.println("3.Delete Employee");
			choice = scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter id:");
				id = scanner.next();
				System.out.println("Enter name");
				name = scanner.next();
				Employee employee = new Employee(id,name);
				String result = employeeservice.addEmployee(employee);   
				System.out.println(result);
				break;
			
			case 2: 
					System.out.println("Enter EmpID:");
					id=scanner.next();
					Employee employee1 = employeeservice.getEmployeeById(id);
					if(employee1!=null) {
						System.out.println(employee1.getEmployeeId());
						System.out.println(employee1.getEmployeeName());
						System.out.println("FOUND");
					}
					else {
						System.out.println("Not Found");
					}
					break;
					
			case 3: 
				System.out.println("Enter EmpID:");
				id=scanner.next();
				Employee employee2 = employeeservice.getEmployeeById(id);
				if(employee2!=null) {
					System.out.println("Deleted");
				}
				break;
		
		}
			System.out.println("Enter status value:");
			status = scanner.nextBoolean();
	}
	}
}
