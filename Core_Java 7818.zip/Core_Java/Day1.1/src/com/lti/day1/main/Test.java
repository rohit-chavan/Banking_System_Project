package com.lti.day1.main;

import com.lti.day1.bean.Employee;
import com.lti.day1.bean.Manager;

public class Test {
	public static void main(String[] args) {
		//Employee emp = new Manager();
		Employee emp1 = new Employee("101","nma");
		Employee emp2 = new Employee("101","nma"); 
		Employee e3 = emp2;
		System.out.println(emp1.hashCode());
		System.out.println(emp2.hashCode());
		System.out.println(emp1.equals(emp2));
		System.out.println(e3.equals(emp2));
		System.out.println(e3.hashCode());
		System.out.println(emp1.toString());
		
		
		
		/*Manager mgr = new Manager();
		mgr.setEmployeeSalary(10000);
		mgr.setEmployeeId("ab001");
		mgr.setEmployeeName("abhi");
		mgr.setDeptId("10");
		mgr.setProjectAllowance(5000);
		mgr.calculateSalary();
		
		
		System.out.println("..Added");
		
		//System.out.println(mgr.getEmployeeId());
		//System.out.println(mgr.getEmployeeName());
		//System.out.println(mgr.getDeptId());
		System.out.println("Project Allowance="+mgr.getProjectAllowance());
		System.out.println("ManagerSalary="+mgr.net_sal);
	}*/
	
	}
}
