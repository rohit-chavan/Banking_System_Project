package com.lti.day1.main;

public abstract class AbstractDemo {
	private String name;
	public AbstractDemo() {
		// TODO Auto-generated constructor stub
	}
	public void show() {
		System.out.println("hello from show");
	}
	
	public static void test() {
		System.out.println("hello from pubg");
	}
}
