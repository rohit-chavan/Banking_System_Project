package com.lti.EmployeeMNGT.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.EmployeeMNGT.bean.EmployeeBean;
import com.lti.EmployeeMNGT.DAO.EmployeeDAO;
import com.lti.EmployeeMNGT.DAO.EmployeeDAOImpl;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public String addEmployee(com.lti.EmployeeMNGT.bean.EmployeeBean employeebean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<com.lti.EmployeeMNGT.bean.EmployeeBean> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.lti.EmployeeMNGT.bean.EmployeeBean getEmployeeById(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String userId, com.lti.EmployeeMNGT.bean.EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		return null;
	}


}
