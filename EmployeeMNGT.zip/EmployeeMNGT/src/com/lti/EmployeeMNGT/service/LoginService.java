package com.lti.EmployeeMNGT.service;

import com.lti.EmployeeMNGT.bean.LoginBean;

public interface LoginService {
	
	public boolean validateUser(LoginBean bean);
	public int getUserStatus(String userId);
	public String getUserType(String userId);
	public String updateUser(String userId, int status);
	

}
