package com.lti.EmployeeMNGT.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.EmployeeMNGT.bean.LoginBean;
import com.lti.EmployeeMNGT.service.LoginService;

@Controller 
public class LoginController {
	
	@Autowired
	LoginService loginService;
	@RequestMapping(value="home.html",method=RequestMethod.GET)
	public String getHomePage() {
		return "home";
	}
	
	@RequestMapping(value="registration.html",method=RequestMethod.GET)
	public String getRegisterPage() {
		return "registration";
	}
	
	
	@RequestMapping(value="validateUser.html",method=RequestMethod.POST)
	public ModelAndView validateUser(@ModelAttribute LoginBean bean)  {
		ModelAndView modelAndView = new ModelAndView();
		if("admin".equals(bean.getUserId()) && "admin".equals(bean.getPassword())) {
			modelAndView.setViewName("success");
		}
		else {
			modelAndView.setViewName("fail");
		}
		return modelAndView;
		
	}
}
