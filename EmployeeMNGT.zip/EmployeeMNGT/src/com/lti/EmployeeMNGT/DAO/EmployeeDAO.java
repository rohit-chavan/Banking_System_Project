package com.lti.EmployeeMNGT.DAO;

import java.util.List;

import com.lti.EmployeeMNGT.bean.EmployeeBean;

public interface EmployeeDAO {

	public String addEmployee(EmployeeDAO employeebean);
	public List<EmployeeDAO> getEmployees();
	public EmployeeDAO getEmployeeById(String userId);
	public String deleteEmployee(String userId);
	public String updateEmployee(String userId,EmployeeDAO employeeBean);
}
