package com.lti.EmployeeMNGT.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.lti.EmployeeMNGT.bean.LoginBean;
//import com.lti.EmployeeManagement.util.Db_Utils;

@Repository("loginDAO")
public class LoginDAOImpl implements LoginDAO{

	@Override
	public boolean validateUser(com.lti.EmployeeMNGT.bean.LoginBean bean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String updateUser(String userId, int status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getUserStatus(String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getUserType(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String insertRecordLogin(com.lti.EmployeeMNGT.bean.LoginBean loginbean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
