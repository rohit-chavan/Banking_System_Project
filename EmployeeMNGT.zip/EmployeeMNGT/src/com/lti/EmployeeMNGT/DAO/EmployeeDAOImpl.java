package com.lti.EmployeeMNGT.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.EmployeeMNGT.bean.EmployeeBean;
import com.lti.EmployeeMNGT.bean.LoginBean;
//import com.lti.EmployeeManagement.util.Db_Utils;
//import com.lti.EmployeeManagement.util.EmployeeUtils;

@Repository("employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO{

	@Override
	public String addEmployee(EmployeeDAO employeebean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeDAO> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeDAO getEmployeeById(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String userId, EmployeeDAO employeeBean) {
		// TODO Auto-generated method stub
		return null;
	}


	

}
