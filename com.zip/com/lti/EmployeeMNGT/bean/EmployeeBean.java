package com.lti.EmployeeMNGT.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EmployeeBean {
	
	@Id
	private String employeeId;
	private String first_name;
	private String last_name;
	private float salary;
	@Override
	public String toString() {
		return "EmployeeBean [employeeId=" + employeeId + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", salary=" + salary + ", getFirst_name()=" + getFirst_name() + ", getLast_name()=" + getLast_name()
				+ ", getSalary()=" + getSalary() + ", getEmployeeId()=" + getEmployeeId() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	

	
	
}
