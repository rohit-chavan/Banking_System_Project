package com.lti.EmployeeMNGT.controller;

import java.util.List;

import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.EmployeeMNGT.bean.EmployeeBean;
import com.lti.EmployeeMNGT.bean.LoginBean;
import com.lti.EmployeeMNGT.service.EmployeeService;
import com.lti.EmployeeMNGT.service.LoginService;

@Controller 
public class LoginController {
	
	@Autowired
	LoginService loginService;
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value="home.html",method=RequestMethod.GET)
	public String getHomePage() {
		return "home";
	}
	
	@RequestMapping(value="registration.html",method=RequestMethod.GET)
	public String getRegisterPage() {
		return "registration";
	}
	
	@RequestMapping(value="getemployeeid.html",method=RequestMethod.GET)
	public String getEmployeeByIdPage() {
		return "getemployeeid";
	}
	
	@RequestMapping(value="getemployees.html",method=RequestMethod.GET)
	public ModelAndView getEmployeesPage() {
		ModelAndView modelAndView = new ModelAndView();
		List<EmployeeBean> list = employeeService.getEmployees();
		modelAndView.addObject("list", list);
		modelAndView.setViewName("getemployees");
		return modelAndView;
	}
	
	
	@RequestMapping(value="getemployeeid.html",method=RequestMethod.POST)
	public ModelAndView getEmployeeById(@RequestParam("get_emp_text") String empId) {
		System.out.println(empId);
		EmployeeBean employeeBean = employeeService.getEmployeeById(empId);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("employeeBean", employeeBean);
		modelAndView.setViewName("getemployeeid");
		return modelAndView;
		
	}
	
	@RequestMapping(value="registration.html", method=RequestMethod.POST)
	 public ModelAndView saveEmployee(@ModelAttribute EmployeeBean employeeBean) {
		System.out.println(employeeBean);
		employeeService.addEmployee(employeeBean);
		return new ModelAndView();
	}
	
	@RequestMapping(value="validateUser.html",method=RequestMethod.POST)
	public ModelAndView validateUser(@ModelAttribute LoginBean bean)  {
		ModelAndView modelAndView = new ModelAndView();
		if("admin".equals(bean.getUserId()) && "admin".equals(bean.getPassword())) {
			modelAndView.setViewName("success");
		}
		else {
			modelAndView.setViewName("fail");
		}
		return modelAndView;
		
	}
}
