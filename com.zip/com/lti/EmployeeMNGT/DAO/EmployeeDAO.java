package com.lti.EmployeeMNGT.DAO;

import java.util.List;

import com.lti.EmployeeMNGT.bean.EmployeeBean;

public interface EmployeeDAO {

	public String addEmployee(EmployeeBean employeebean);
	public List<EmployeeBean> getEmployees();
	public EmployeeBean getEmployeeById(String userId);
	public String deleteEmployee(String userId);
	public String updateEmployee(String userId,EmployeeBean employeeBean);
}
