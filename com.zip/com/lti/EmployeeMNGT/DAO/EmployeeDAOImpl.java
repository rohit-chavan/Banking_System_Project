package com.lti.EmployeeMNGT.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.lti.EmployeeMNGT.bean.EmployeeBean;
import com.lti.EmployeeMNGT.bean.LoginBean;
//import com.lti.EmployeeManagement.util.Db_Utils;
//import com.lti.EmployeeManagement.util.EmployeeUtils;

@Repository("employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO{
	
	/*@Autowired
	JdbcTemplate jdbcTemplate;*/
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public String addEmployee(EmployeeBean employeebean) {
		
		// TODO Auto-generated method stub
		/*
		String query = "insert into emp values(?,?,?,?)";
		jdbcTemplate.update(query, employeebean.getEmployeeId(),employeebean.getFirst_name(),employeebean.getLast_name(),employeebean.getSalary());
		return "success";*/
		Session session = sessionFactory.getCurrentSession(); 
		session.save(employeebean);
		return "success";
	}

	@Override
	public List<EmployeeBean> getEmployees() {
		return null;
		// TODO Auto-generated method stub
		/*String query = "select * from emp";
		List<EmployeeBean> list =jdbcTemplate.query(query,new BeanPropertyRowMapper<EmployeeBean>(EmployeeBean.class));
		return list;*/
	}

	@Override
	public EmployeeBean getEmployeeById(String userId) {
		return null;
		// TODO Auto-generated method stub
	/*	String query = "select * from emp where employeeId = ?";
		EmployeeBean employeeBean=jdbcTemplate.queryForObject(query, new Object[] {userId}, new BeanPropertyRowMapper<EmployeeBean>(EmployeeBean.class));
		
		return employeeBean;*/
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String userId, EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		return null;
	}


	

}
