package com.lti.EmployeeMNGT.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.EmployeeMNGT.bean.EmployeeBean;
import com.lti.EmployeeMNGT.DAO.EmployeeDAO;
import com.lti.EmployeeMNGT.DAO.EmployeeDAOImpl;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeDAO employeeDAO;
	
	@Override
	public String addEmployee(com.lti.EmployeeMNGT.bean.EmployeeBean employeebean) {
		// TODO Auto-generated method stub
		return employeeDAO.addEmployee(employeebean);
	}

	@Override
	public List<com.lti.EmployeeMNGT.bean.EmployeeBean> getEmployees() {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployees();
	}

	@Override
	public com.lti.EmployeeMNGT.bean.EmployeeBean getEmployeeById(String userId) {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployeeById(userId);
	}

	@Override
	public String deleteEmployee(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String userId, com.lti.EmployeeMNGT.bean.EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		return null;
	}


}
