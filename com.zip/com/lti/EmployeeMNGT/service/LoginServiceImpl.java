package com.lti.EmployeeMNGT.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.EmployeeMNGT.bean.LoginBean;
import com.lti.EmployeeMNGT.DAO.LoginDAO;
import com.lti.EmployeeMNGT.DAO.LoginDAOImpl;

@Service("loginService")
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	LoginDAO loginDAO;
	@Override
	public boolean validateUser(LoginBean bean) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getUserStatus(String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getUserType(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateUser(String userId, int status) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
